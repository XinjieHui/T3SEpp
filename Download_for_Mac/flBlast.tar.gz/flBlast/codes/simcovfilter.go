//simcovfilter
//USAGE: ./simcovfilter BEST_HIT >BLAST_FILTER

package main

import (
  "fmt"
  "os"
  "io"
  "bufio"
  "strings"
  "strconv"
)

func main () {
  usage := "simcovfilter DB_PROT_LEN DB_PROT_FAM DB_PROT_FUNC BEST_HIT"
  if len(os.Args) < 5 {
    fmt.Printf("Argument not right!\n")
    fmt.Printf("USAGE: %s\n",usage)
    return
  }

  dbProtLenName := os.Args[1]
  dbProtFamName := os.Args[2]
  dbProtFuncName := os.Args[3]
  bestHitName := os.Args[4]

  dbProtLenFile, openErr1 := os.Open(dbProtLenName)
  if openErr1 != nil {
    fmt.Printf("Error happened in opening %s!\n",dbProtLenName)
    return
  }
  defer dbProtLenFile.Close()

  dbProtLenReader := bufio.NewReader(dbProtLenFile)
  dbProtLen := make(map[string]int)
  for {
    line, readErr1 := dbProtLenReader.ReadString('\n')
    line = strings.Trim(line,"\r\n")
    line = strings.Trim(line,"\n")
    if len(line) != 0 {
      lineArray := strings.Split(line,"\t")
      dbProtLen[lineArray[0]],_ = strconv.Atoi(lineArray[1])
    }  
    if readErr1 == io.EOF {
      break
    }
  }

  dbProtFamFile, openErr2 := os.Open(dbProtFamName)
  if openErr2 != nil {
    fmt.Printf("Error happened in opening %s!\n",dbProtFamName)
    return
  }
  defer dbProtFamFile.Close()

  dbProtFamReader := bufio.NewReader(dbProtFamFile)
  dbProtFam := make(map[string]string)
  for {
    line, readErr2 := dbProtFamReader.ReadString('\n')
    line = strings.Trim(line,"\r\n")
    line = strings.Trim(line,"\n")
    if len(line) != 0 {
      lineArray2 := strings.Split(line,"\t")
      dbProtFam[lineArray2[0]] = lineArray2[1]
    }  
    if readErr2 == io.EOF {
      break
    }
  }

  dbProtFuncFile, openErr3 := os.Open(dbProtFuncName)
  if openErr3 != nil {
    fmt.Printf("Error happened in opening %s!\n",dbProtFuncName)
    return
  }
  defer dbProtFuncFile.Close()

  dbProtFuncReader := bufio.NewReader(dbProtFuncFile)
  dbProtFunc := make(map[string]string)
  for {
    line, readErr3 := dbProtFuncReader.ReadString('\n')
    line = strings.Trim(line,"\r\n")
    line = strings.Trim(line,"\n")
    if len(line) != 0 {
      lineArray3 := strings.Split(line,"\t")
      dbProtFunc[lineArray3[0]] = lineArray3[1]
    }  
    if readErr3 == io.EOF {
      break
    }
  }
  
  bestHitFile, openErr4 := os.Open(bestHitName)
  if openErr4 != nil {
    fmt.Printf("Error happened in opening %s!\n",bestHitName)
    return
  }
  defer bestHitFile.Close()

  bestHitReader := bufio.NewReader(bestHitFile)
  fmt.Printf("Query\tSubject\tSubject_Acc\tFamily\tFunction\tCoverage\tSimilarity\n")
  for {
    line, readErr4 := bestHitReader.ReadString('\n')
    line = strings.Trim(line,"\r\n")
    line = strings.Trim(line,"\n")
    if len(line) != 0 {
      lineArray4 := strings.Split(line,"\t")
      nameArray := strings.Split(lineArray4[1],"|")
      sim,_ := strconv.ParseFloat(lineArray4[2],32)
      sim = sim/100
      dbSt,_ := strconv.Atoi(lineArray4[8])
      dbEn,_ := strconv.Atoi(lineArray4[9])
      covLen := dbEn - dbSt + 1
      lenCov := float32(covLen) / float32(dbProtLen[nameArray[0]])
      if lenCov >= 0.7 && sim >= 0.3 {
        fmt.Printf("%s\t%s\t%s\t%s\t%s\t%.2f\t%.2f\n",lineArray4[0],nameArray[0],nameArray[1],dbProtFam[nameArray[0]],dbProtFunc[nameArray[0]],lenCov,sim)
      }
    }  
    if readErr4 == io.EOF {
      break
    }
  } 	
}
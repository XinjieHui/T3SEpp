#! /usr/bin/perl 

# USAGE: perl  T3MM.pl  FASTA_SEQ_With_100_aa  >RESULT.txt

my $infile1 = "./T3_MM/pos.fa";
my $infile2 = "./T3_MM/neg.fa"; 
my $infile3 = $ARGV[0]; #TESTING;
my $seqCount = 0;
my $seq = '';
my $initAA = '';
my %initAA = ();
my %PaaCount1 = ();
my %NaaCount1 = ();
my %bi_aa = '';
my %PaaCount2 = ();
my %NaaCount2 = ();
my %logInitRatio = ();
my %logBiRatio = ();
my $prot = '';
my $totLogRatio = 0;
my $t3mm = 0;

open(IN1,"$infile1")||die"Cannot open $infile1!\n"; 
while(<IN1>){
  if(/^\>/){
   $seqCount++;
  }
  elsif(/^(\S+)/){
   $seq = $1;
   $initAA = substr($seq,0,1);
   $initAA{$initAA} = '';
   if(!defined $PaaCount1{$initAA}){
     $PaaCount1{$initAA} = 1;
   } else{
     $PaaCount1{$initAA}++;
   }
   for(my $i=0;$i<length($seq)-1;$i++){
     $bi_aa = substr($seq,$i,2);
     $bi{$bi_aa} = '';
     if(!defined $PaaCount2{$bi_aa}){
       $PaaCount2{$bi_aa} = 1;
     } else {
       $PaaCount2{$bi_aa}++;
     }
   }
  }
}
close(IN1);

$seqCount = 0;

open(IN2,"$infile2")||die"Cannot open $infile2!\n"; 
while(<IN2>){
  if(/^\>/){
   $seqCount++;
  }
  elsif(/^(\S+)/){
   $seq = $1;
   $initAA = substr($seq,0,1);
   $initAA{$initAA} = '';
   if(!defined $NaaCount1{$initAA}){
     $NaaCount1{$initAA} = 1;
   } else{
     $NaaCount1{$initAA}++;
   }
   for(my $i=0;$i<length($seq)-1;$i++){
     $bi_aa = substr($seq,$i,2);
     $bi{$bi_aa} = '';
     if(!defined $NaaCount2{$bi_aa}){
       $NaaCount2{$bi_aa} = 1;
     } else {
       $NaaCount2{$bi_aa}++;
     }
   }
  }
}
close(IN2);

foreach my $k(keys %initAA){
  if(!defined $PaaCount1{$k}){
    $PaaCount1{$k} = 1;
  }
  if(!defined $NaaCount1{$k}){
    $NaaCount1{$k} = 1;
  }
  $logInitRatio{$k} = log($PaaCount1{$k})/log(2) - log($NaaCount1{$k})/log(2);
}

foreach my $k(keys %bi){
  if(!defined $PaaCount2{$k}){
    $PaaCount2{$k} = 1;
  }
  if(!defined $NaaCount2{$k}){
    $NaaCount2{$k} = 1;
  }
  $logBiRatio{$k} = log($PaaCount2{$k})/log(2) - log($NaaCount2{$k})/log(2);
}

open(IN3,"$infile3")||die"Cannot open $infile3!\n";
open(OUT,">T3_MM.out.csv")||die"Cannot open 'T3_MM.out.csv'!\n";
print OUT "prot",",","score",",","T3SE or not","\n"; 
while(<IN3>){
  if(/^\>(\S+)/){
   $prot = $1;
   $totLogRatio = 0;
  }
  elsif(/^(\S+)/){
   $seq = $1;
   $initAA = substr($seq,0,1);
   if(!defined $logInitRatio{$initAA}){
     $logInitRatio{$initAA} = 0;
   }
   $totLogRatio = $logInitRatio{$initAA};

   for(my $i=0;$i<99;$i++){
     $bi_aa = substr($seq,$i,2);
     if(!defined $logBiRatio{$bi_aa}){
       $logBiRatio{$bi_aa} = 0;
     }
     $totLogRatio += $logBiRatio{$bi_aa};
   }
   $t3mm = $totLogRatio / 100;
   if($t3mm > 0){
     print OUT $prot,",",$t3mm,",","1","\n";
   } else{
     print OUT $prot,",",$t3mm,",","0","\n";
   }
  } 
}
close(IN3);
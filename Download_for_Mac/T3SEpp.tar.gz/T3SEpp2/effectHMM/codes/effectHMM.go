//batch_hmmsearch.exe  hmmsearch.exe  hmmprofile存放的目录  序列文件(会自动去除N51个，保留剩余大于30aa的序列，并生成跟输入文件路径一样的文件)  要输出的目录(既hmmsearch.out文件)  >输出文件
package main

import (
	"bufio"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"os/exec"
	"strings"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	fastafilename := os.Args[3]
	fastafile, openfastaErr := os.Open(fastafilename)
	if openfastaErr != nil {
		fmt.Printf("打开%s错误", openfastaErr)
	}
	defer fastafile.Close()
	fastaReader := bufio.NewReader(fastafile)
	var seq string
	fastafiledeleteN51name := strings.Replace(os.Args[3], ".fasta", "", -1) + "deleteN51.fasta"
	fastafiledeleteN51, _ := os.Create(fastafiledeleteN51name)
	seqname_FAMcounts := make(map[string]string)
	var seqnamestring []string
	for {
		fastaraw, readfastaErr := fastaReader.ReadString('\n')
		fastaraw = seqTrim(fastaraw)
		if len(fastaraw) > 0 {
			if strings.Contains(fastaraw, ">") && len(seq) > 1 {
				if len(seq) >= 81 {
					fastafiledeleteN51.WriteString(seq[51:] + "\n")
				}
				seq = ""
			}
			if strings.Contains(fastaraw, ">") {
				seqnamestring = append(seqnamestring, fastaraw[1:])
				seqname_FAMcounts[fastaraw[1:]] = "-"
				fastafiledeleteN51.WriteString(fastaraw + "\n")
			} else {
				seq = seq + fastaraw
			}
		}
		if readfastaErr == io.EOF {
			if len(seq) > 1 {
				if len(seq) >= 81 {
					fastafiledeleteN51.WriteString(seq[51:] + "\n")
				}
				seq = ""
			}
			if strings.Contains(fastaraw, ">") {
				fastafiledeleteN51.WriteString(fastaraw + "\n")
			} else {
				seq = seq + fastaraw
			}
			break
		}
	}
	catalogname := os.Args[2]
	outputcatalogname := os.Args[4]
	files, _ := ioutil.ReadDir(catalogname)
	for i, _ := range files {
		hmmFilename := catalogname + "/" + files[i].Name()
		output_HMMsearchfilename := outputcatalogname + "/" + strings.Replace(files[i].Name(), ".hmm", "", -1) + "_search_input_seqfiledeleteN51.out"
		c := exec.Command(os.Args[1], hmmFilename, fastafiledeleteN51name)
		buf, err := c.Output()
		if err != nil {
			fmt.Printf("Error: %s\n", err)
		}
		output_HMMsearchfile, _ := os.Create(output_HMMsearchfilename)
		output_HMMsearchfile.WriteString(string(buf))
	}
	outputfiles, _ := ioutil.ReadDir(outputcatalogname)
	for i, _ := range outputfiles {
		FAM := strings.Replace(outputfiles[i].Name(), "_search_input_seqfiledeleteN51.out", "", -1)
		outputfilename := outputcatalogname + "/" + outputfiles[i].Name()
		out_file, openoutfileErr := os.Open(outputfilename)
		if openoutfileErr != nil {
			fmt.Printf("There is an error in opening the %s!\n", outputfiles[i].Name())
			return
		}
		defer out_file.Close()
		out_fileReader := bufio.NewReader(out_file)
		var flag int = 0
		for {
			outraw, readoutErr := out_fileReader.ReadString('\n')
			outraw = seqTrim(outraw)
			if len(outraw) < 1 || strings.Contains(outraw, "No hits detected") {
				continue
			}
			if strings.Contains(outraw, "Domain annotation") || strings.Contains(outraw, "inclusion threshold") {
				break
			}
			pat := strings.Contains(outraw, "-----------")
			if flag == 1 {
				seqname := strings.Split(outraw[60:], " ")[0]

				for key, _ := range seqname_FAMcounts {
					if strings.Contains(key, seqname) {
						seqname_FAMcounts[key] = strings.Replace(seqname_FAMcounts[key], "-", "", -1)
						seqname_FAMcounts[key] = seqname_FAMcounts[key] + "/" + FAM
						break

					}
				}
			}
			if pat {
				flag = 1
			}
			if readoutErr == io.EOF {
				break
			}
		}
	}
	for _, seqname := range seqnamestring {
		seqnamesplit := strings.Split(seqname, " ")
		fmt.Printf("%s\t%s\n", seqnamesplit[0], strings.Replace(seqname_FAMcounts[seqname], "/", "", 1))
	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

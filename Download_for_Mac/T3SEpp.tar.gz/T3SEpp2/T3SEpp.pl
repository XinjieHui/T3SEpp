# perl  T3SEpp.pl  -prot  test.fa   -prom  testProm.fa   -psortb   psortb.txt   -signalp  signalp.txt   -tmhmm  tmhmm.txt   -cutoff  0.5

my $testProtFile = '';
my $testPromFile = '';
my $testPsortbFile = '';
my $testSignalpFile = '';
my $testTmhmmFile = '';
my $cutoff = 0.5;
my $prot = '';
my %ann = ();
my $annLine = '';
my $mod = '';
my $score = 0;

my $usage = "USAGE: perl  T3SEpp.pl  -prot  prot.fa   -prom  promoter.fa   -psortb   psortb.txt   -signalp  signalp.txt   -tmhmm  tmhmm.txt  -cutoff 0.5\n";

for(my $i=0;$i<@ARGV;$i++){
  if($ARGV[$i] eq '-prot'){
    $testProtFile = $ARGV[$i+1];
  } elsif($ARGV[$i] eq '-prom'){
    $testPromFile = $ARGV[$i+1];
  } elsif($ARGV[$i] eq '-psortb'){
    $testPsortbFile = $ARGV[$i+1];
  } elsif($ARGV[$i] eq '-signalp'){
    $testSignalpFile = $ARGV[$i+1];
  } elsif($ARGV[$i] eq '-tmhmm'){
    $testTmhmmFile = $ARGV[$i+1];
  } elsif($ARGV[$i] eq '-cutoff'){
    $cutoff = $ARGV[$i+1] + 1 - 1;
  }
}

if(length($testProtFile)== 0){
  die "No input protein sequence file!\n$usage\n";
} else{
  open(IN,"$testProtFile")||die"The protein sequence file does not exist!\n$usage\n";
  close(IN);  
}

if(length($testPromFile) > 0){
  open(IN,"$testPromFile")||die"The promoter sequence file does not exist!\n$usage\n";
  close(IN);
}

if(length($testPsortbFile) > 0){
  open(IN,"$testPsortbFile")||die"The PSORTb prediction file does not exist!\n$usage\n";
  close(IN);
}

if(length($testSignalpFile) > 0){
  open(IN,"$testSignalpFile")||die"The SignalP prediction file does not exist!\n$usage\n";
  close(IN);
}

if(length($testTmhmmFile) > 0){
  open(IN,"$testTmhmmFile")||die"The TMHMM prediction file does not exist!\n$usage\n";
  close(IN);
}

system("rm -R Results");

system("./effectHMM/bin/effectHMM hmmsearch ./effectHMM/hmmprofile $testProtFile ./effectHMM/out >effectHMM.out.txt");
system("rm *deleteN51.fasta");
system("rm -R ./effectHMM/out/*.out");

system("./sigHMM/bin/sigHMM hmmsearch ./sigHMM/hmmprofile $testProtFile ./sigHMM/out >sigHMM.out.txt");
system("rm *61.fasta");
system("rm -R ./sigHMM/out/*.out");

system("blastp -query $testProtFile -db ./flBlast/database/Validated_effectors_20160311 -evalue 1e-5 -outfmt 6 -out blast.1.txt");
system("./flBlast/bin/bestpicker blast.1.txt >blast.2.txt");
system("./flBlast/bin/simcovfilter ./flBlast/database/Validated_effectors_20160311.length ./flBlast/database/Validated_effectors_20160311.family ./flBlast/database/Validated_effectors_20160311.function blast.2.txt >flBlast.out0.txt");
system("rm blast.*");

open(IN1,"flBlast.out0.txt")||die"Cannot open flBlast.out0.txt!\n";
open(OUT1,">flBlast.out.txt")||die"Cannot open flBlast.out.txt!\n";
print OUT1 "Query\tSubject\tSubject_Acc\tFamily\tFunction\tCoverage\tSimilarity\n";
while(<IN1>){
  if(/^(\S+)\t/){
    $prot = $1;
    $ann{$prot} = $_;
  }
}
close(IN1);

open(IN2,"$testProtFile")||die"Cannot open $testProtFile!\n";
while(<IN2>){
  if(/\>(\S+)/){
    $prot = $1;
    if(defined $ann{$prot}){
      print OUT1 $ann{$prot};
    } else{
      print OUT1 $prot,"\t","-","\t","-","\t","-","\t","-","\t","-","\t","-","\n";
    }
  }
}
close(IN2);
close(OUT1);
system("rm flBlast.out0.txt");

system("./cbdHMM/bin/cbdHMM $testProtFile >cbdHMM.out.txt");

if(length($testPromFile) == 0){
  system("./transHMM/bin/makeprom $testProtFile >transHMM.out.txt");
} else {
  system("./transHMM/bin/transHMM ./transHMM/bin/ExsA_pattern ./transHMM/bin/HrpB_pattern ./transHMM/bin/HrpL_pattern ./transHMM/bin/InvF_pattern ./transHMM/bin/SsrB_pattern ./transHMM/bin/TtsI_pattern $testPromFile >transHMM.out.txt");
}

system("perl T3SEppML.pl $testProtFile");

if(length($testPsortbFile) == 0){
  system("./PSORTb/bin/makepsortb $testProtFile >PSORTb.out.txt");
} else {
  system("cp $testPsortbFile PSORTb.out.txt");
}

if(length($testSignalpFile) == 0){
  system("./SignalP/bin/makesignalp $testProtFile >SignalP.out.txt");
} else {
  system("cp $testSignalpFile SignalP.out.txt");
}

if(length($testTmhmmFile) == 0){
  system("./TMHMM/bin/maketmhmm $testProtFile >TMHMM.out.txt");
} else {
  system("cp $testTmhmmFile TMHMM.out.txt");
}

system("./T3SEppPrep >T3SEppPrep.txt");
system("./T3SEpp T3SEppPrep.txt >T3SEpp.out0.txt");

open(IN3,"T3SEpp.out0.txt")||die"Cannot open T3SEpp.out0.txt!\n";
open(OUT2,">T3SEpp.out.txt")||die"Cannot open T3SEpp.out.txt!\n";
while(<IN3>){
  if(/^prot\tT3SEppML/){
    $annLine = $_;
    $annLine =~ s/\n//g;
    print OUT2 $annLine,"\t","Pred\n";
  } elsif(/^(.*)\t(\S+)$/){
    $mod = $1;
    $score = $2 + 1 - 1;
    if($score >= $cutoff){
      print OUT2 $mod,"\t",$score,"\t","T3S","\n";
    } else {
      print OUT2 $mod,"\t",$score,"\t","non-T3S","\n";
    }
  }
}
close(IN3);
close(OUT2);

system("rm T3SEpp.out0.txt");
system("rm T3SEppPrep.txt");
system("mkdir Results");
system("mv *.out.txt ./Results/");


#mergeDL.pl  <T3SEdnn.out.csv>  <T3SErnn.out.csv>  >T3SEdl.out.txt

my $prot = '';
my %dnn = ();
open(IN1,"$ARGV[0]")||die"Cannot open 'T3SEdnn.out.csv'!\n";
while(<IN1>){
  if(/^(\S+)\s*(.*)\,(\S+)\,(\d+)$/){
     $prot = $1;
     $dnnValue{$prot} = $3;
     $dnn{$prot} = $4;
  }
}
close(IN1);

print "prot\tT3SEdnn|T3SErnn\n";
open(IN2,"$ARGV[1]")||die"Cannot open 'T3SErnn.out.csv'!\n";
while(<IN2>){
  if(/^(\S+)\s*(.*)\,(\S+)\,(\d+)$/){
     $prot = $1;
     if(defined $dnn{$prot}){
       print $prot,"\t",$dnnValue{$prot},"|",$3,"\t",$dnn{$prot},"|",$4,"\n";
     }
  }
}
close(IN2);
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strings"
)

func main() {
	if len(os.Args) <= 1 {
		fmt.Printf("There is no input file!\n")
		return
	}
	inputFileName := os.Args[1]
	inputFile, openErr := os.Open(inputFileName)
	if openErr != nil {
		fmt.Printf("Error happened in opening %s\n", inputFileName)
		return
	}
	defer inputFile.Close()
	inputReader := bufio.NewReader(inputFile)
	var seq_name, seq string
	var seqlen int
	Llocation := 0
	aL := 0
	Flocation := 0
	aF := 0
	Mlocation := 0
	aM := 0
	for {
		inputstring, readErr := inputReader.ReadString('\n')
		inputstring = seqTrim(inputstring)
		if readErr == io.EOF {
			break
		}
		pat, _ := regexp.MatchString("^>", inputstring) //也可以：pat := strings.Contains(inputstring, ">")
		seqlen = len(seq)
		if pat && seqlen >= 1 {
			seq = seqTrim(seq)
			for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
				Llocation = strings.Index(seq[Llocation:], "C")
				if Llocation == -1 || aL+Llocation+27 > seqlen {
					break
				}

				if strings.ContainsAny(seq[aL+Llocation+1:aL+Llocation+2], "AG") && strings.Contains(seq[aL+Llocation+2:aL+Llocation+8], "ACAAAA") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.Contains(seq[aL+Llocation+11:aL+Llocation+13], "CG") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.Contains(seq[aL+Llocation+19:aL+Llocation+20], "C") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+24], "TGA") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "CT") && strings.Contains(seq[aL+Llocation+25:aL+Llocation+26], "A") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "GA") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
				} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+6], "TAAAA") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "AT") && strings.ContainsAny(seq[aL+Llocation+8:aL+Llocation+9], "AT") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.ContainsAny(seq[aL+Llocation+11:aL+Llocation+12], "CT") && strings.Contains(seq[aL+Llocation+12:aL+Llocation+13], "G") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.ContainsAny(seq[aL+Llocation+19:aL+Llocation+20], "AGT") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+22], "T") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "CA") && strings.Contains(seq[aL+Llocation+25:aL+Llocation+26], "A") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "TAG") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
				} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+7], "TTAAAA") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.Contains(seq[aL+Llocation+11:aL+Llocation+13], "AG") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.Contains(seq[aL+Llocation+19:aL+Llocation+20], "A") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+27], "TGACAA") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
				} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+27], "TAAAAACTCCCGACCAATATTCACTA") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])

				}

				Llocation = aL + Llocation + 1
				aL = Llocation //a用于累加每一次循环,L的位置
			}
			for {
				Flocation = strings.Index(seq[Flocation:], "G")
				if Flocation == -1 || aF+Flocation+27 > seqlen {
					break
				}
				if strings.Contains(seq[aF+Flocation+1:aF+Flocation+7], "TTAAAA") && strings.ContainsAny(seq[aF+Flocation+9:aF+Flocation+10], "ACT") && strings.Contains(seq[aF+Flocation+11:aF+Flocation+13], "CG") && strings.ContainsAny(seq[aF+Flocation+13:aF+Flocation+14], "AGT") && strings.Contains(seq[aF+Flocation+14:aF+Flocation+15], "C") && strings.ContainsAny(seq[aF+Flocation+15:aF+Flocation+16], "CTG") && strings.ContainsAny(seq[aF+Flocation+18:aF+Flocation+19], "CGT") && strings.Contains(seq[aF+Flocation+19:aF+Flocation+20], "A") && strings.ContainsAny(seq[aF+Flocation+20:aF+Flocation+21], "CGT") && strings.Contains(seq[aF+Flocation+21:aF+Flocation+27], "TGACAG") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aF+Flocation+1, seq[aF+Flocation:aF+Flocation+27])
				}

				Flocation = aF + Flocation + 1
				aF = Flocation //a用于累加每一次循环,F的位置
			}
			for {
				Mlocation = strings.Index(seq[Mlocation:], "T")
				if Mlocation == -1 || aM+Mlocation+27 > seqlen {
					break
				}
				if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+7], "AAAAAA") && strings.ContainsAny(seq[aM+Mlocation+9:aM+Mlocation+10], "ACT") && strings.Contains(seq[aM+Mlocation+11:aM+Mlocation+13], "CG") && strings.ContainsAny(seq[aM+Mlocation+13:aM+Mlocation+14], "AGT") && strings.Contains(seq[aM+Mlocation+14:aM+Mlocation+15], "C") && strings.ContainsAny(seq[aM+Mlocation+15:aM+Mlocation+16], "CTG") && strings.ContainsAny(seq[aM+Mlocation+18:aM+Mlocation+19], "CGT") && strings.Contains(seq[aM+Mlocation+19:aM+Mlocation+20], "C") && strings.ContainsAny(seq[aM+Mlocation+20:aM+Mlocation+21], "CGT") && strings.Contains(seq[aM+Mlocation+21:aM+Mlocation+27], "TGATAG") {
					fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
				}

				Mlocation = aM + Mlocation + 1
				aM = Mlocation //a用于累加每一次循环,F的位置
			}

			seq = ""
			Llocation = 0
			aL = 0
			Flocation = 0
			aF = 0
			Mlocation = 0
			aM = 0

		}
		if pat {
			seq_name = inputstring[1:]

		}
		if !pat {
			seq = seq + inputstring
		}
	}

	if len(seq) >= 1 { //此是输出最后一条序列
		seq = seqTrim(seq)
		for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
			Llocation = strings.Index(seq[Llocation:], "C")
			if Llocation == -1 || aL+Llocation+27 > seqlen {
				break
			}

			if strings.ContainsAny(seq[aL+Llocation+1:aL+Llocation+2], "AG") && strings.Contains(seq[aL+Llocation+2:aL+Llocation+8], "ACAAAA") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.Contains(seq[aL+Llocation+11:aL+Llocation+13], "CG") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.Contains(seq[aL+Llocation+19:aL+Llocation+20], "C") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+24], "TGA") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "CT") && strings.Contains(seq[aL+Llocation+25:aL+Llocation+26], "A") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "GA") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
			} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+6], "TAAAA") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "AT") && strings.ContainsAny(seq[aL+Llocation+8:aL+Llocation+9], "AT") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.ContainsAny(seq[aL+Llocation+11:aL+Llocation+12], "CT") && strings.Contains(seq[aL+Llocation+12:aL+Llocation+13], "G") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.ContainsAny(seq[aL+Llocation+19:aL+Llocation+20], "AGT") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+22], "T") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "CA") && strings.Contains(seq[aL+Llocation+25:aL+Llocation+26], "A") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "TAG") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
			} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+7], "TTAAAA") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "ACT") && strings.Contains(seq[aL+Llocation+11:aL+Llocation+13], "AG") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "AGT") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+15], "C") && strings.ContainsAny(seq[aL+Llocation+15:aL+Llocation+16], "CTG") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "CGT") && strings.Contains(seq[aL+Llocation+19:aL+Llocation+20], "A") && strings.ContainsAny(seq[aL+Llocation+20:aL+Llocation+21], "CGT") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+27], "TGACAA") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])
			} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+27], "TAAAAACTCCCGACCAATATTCACTA") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+27])

			}

			Llocation = aL + Llocation + 1
			aL = Llocation //a用于累加每一次循环,L的位置
		}
		for {
			Flocation = strings.Index(seq[Flocation:], "G")
			if Flocation == -1 || aF+Flocation+27 > seqlen {
				break
			}
			if strings.Contains(seq[aF+Flocation+1:aF+Flocation+7], "TTAAAA") && strings.ContainsAny(seq[aF+Flocation+9:aF+Flocation+10], "ACT") && strings.Contains(seq[aF+Flocation+11:aF+Flocation+13], "CG") && strings.ContainsAny(seq[aF+Flocation+13:aF+Flocation+14], "AGT") && strings.Contains(seq[aF+Flocation+14:aF+Flocation+15], "C") && strings.ContainsAny(seq[aF+Flocation+15:aF+Flocation+16], "CTG") && strings.ContainsAny(seq[aF+Flocation+18:aF+Flocation+19], "CGT") && strings.Contains(seq[aF+Flocation+19:aF+Flocation+20], "A") && strings.ContainsAny(seq[aF+Flocation+20:aF+Flocation+21], "CGT") && strings.Contains(seq[aF+Flocation+21:aF+Flocation+27], "TGACAG") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aF+Flocation+1, seq[aF+Flocation:aF+Flocation+27])
			}

			Flocation = aF + Flocation + 1
			aF = Flocation //a用于累加每一次循环,F的位置
		}
		for {
			Mlocation = strings.Index(seq[Mlocation:], "T")
			if Mlocation == -1 || aM+Mlocation+27 > seqlen {
				break
			}
			if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+7], "AAAAAA") && strings.ContainsAny(seq[aM+Mlocation+9:aM+Mlocation+10], "ACT") && strings.Contains(seq[aM+Mlocation+11:aM+Mlocation+13], "CG") && strings.ContainsAny(seq[aM+Mlocation+13:aM+Mlocation+14], "AGT") && strings.Contains(seq[aM+Mlocation+14:aM+Mlocation+15], "C") && strings.ContainsAny(seq[aM+Mlocation+15:aM+Mlocation+16], "CTG") && strings.ContainsAny(seq[aM+Mlocation+18:aM+Mlocation+19], "CGT") && strings.Contains(seq[aM+Mlocation+19:aM+Mlocation+20], "C") && strings.ContainsAny(seq[aM+Mlocation+20:aM+Mlocation+21], "CGT") && strings.Contains(seq[aM+Mlocation+21:aM+Mlocation+27], "TGATAG") {
				fmt.Printf("%s\tExsA\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
			}

			Mlocation = aM + Mlocation + 1
			aM = Mlocation //a用于累加每一次循环,F的位置
		}

		seq = ""
		Llocation = 0
		aL = 0
		Flocation = 0
		aF = 0
		Mlocation = 0
		aM = 0

	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

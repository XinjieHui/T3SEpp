package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strings"
)

func main() {
	if len(os.Args) <= 1 {
		fmt.Printf("There is no input file!\n")
		return
	}
	inputFileName := os.Args[1]
	inputFile, openErr := os.Open(inputFileName)
	if openErr != nil {
		fmt.Printf("Error happened in opening %s\n", inputFileName)
		return
	}
	defer inputFile.Close()
	inputReader := bufio.NewReader(inputFile)
	var seq_name, seq string
	var seqlen int
	Llocation := 0
	aL := 0
	Flocation := 0
	aF := 0
	Mlocation := 0
	aM := 0
	for {
		inputstring, readErr := inputReader.ReadString('\n')
		inputstring = seqTrim(inputstring)
		if readErr == io.EOF {
			break
		}
		pat, _ := regexp.MatchString("^>", inputstring) //也可以：pat := strings.Contains(inputstring, ">")
		seqlen = len(seq)
		if pat && seqlen >= 1 {
			seq = seqTrim(seq)
			for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
				Llocation = strings.Index(seq[Llocation:], "G")
				if Llocation == -1 || aL+Llocation+28 > seqlen {
					break
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "TCAG") && strings.ContainsAny(seq[aL+Llocation+5:aL+Llocation+6], "CGT") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "GT") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "TCA") && strings.ContainsAny(seq[aL+Llocation+10:aL+Llocation+11], "CTG") && strings.ContainsAny(seq[aL+Llocation+11:aL+Llocation+12], "GA") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "CA") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+16], "AG") && strings.ContainsAny(seq[aL+Llocation+16:aL+Llocation+17], "CGT") && strings.ContainsAny(seq[aL+Llocation+17:aL+Llocation+18], "TC") && strings.ContainsAny(seq[aL+Llocation+21:aL+Llocation+22], "CTG") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "CT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
					fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "TCAG") && strings.ContainsAny(seq[aL+Llocation+5:aL+Llocation+6], "CT") && strings.Contains(seq[aL+Llocation+6:aL+Llocation+16], "TTCTCGAAAG") && strings.ContainsAny(seq[aL+Llocation+16:aL+Llocation+17], "CG") && strings.Contains(seq[aL+Llocation+17:aL+Llocation+18], "T") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "AT") && strings.ContainsAny(seq[aL+Llocation+19:aL+Llocation+20], "AT") && strings.ContainsAny(seq[aL+Llocation+21:aL+Llocation+22], "CT") && strings.Contains(seq[aL+Llocation+22:aL+Llocation+23], "C") && strings.ContainsAny(seq[aL+Llocation+23:aL+Llocation+24], "GAT") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "ACG") && strings.ContainsAny(seq[aL+Llocation+25:aL+Llocation+26], "TA") && strings.Contains(seq[aL+Llocation+26:aL+Llocation+28], "TA") {
					fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				Llocation = aL + Llocation + 1
				aL = Llocation //a用于累加每一次循环,L的位置
			}
			for {
				Flocation = strings.Index(seq[Flocation:], "G")
				if Flocation == -1 || aF+Flocation+26 > seqlen {
					break
				}
				if strings.Contains(seq[aF+Flocation+1:aF+Flocation+26], "TCAGCTTAACGAAGCATCGTGCGTA") {
					fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aF+Flocation+1, seq[aF+Flocation:aF+Flocation+26])
				}
				Flocation = aF + Flocation + 1
				aF = Flocation //a用于累加每一次循环,F的位置
			}
			for {
				Mlocation = strings.Index(seq[Mlocation:], "M")
				if Mlocation == -1 || aM+Mlocation+27 > seqlen {
					break
				}

				if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+27], "TCAGCGTGTCGTCAGCTCGCCTCGCT") {
					fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
				} else if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+27], "TCAGCTGAACGTCAGTTGTGCGCGTC") {
					fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
				}

				Mlocation = aM + Mlocation + 1
				aM = Mlocation //a用于累加每一次循环,F的位置
			}

			seq = ""
			Llocation = 0
			aL = 0
			Flocation = 0
			aF = 0
			Mlocation = 0
			aM = 0

		}
		if pat {
			seq_name = inputstring[1:]

		}
		if !pat {
			seq = seq + inputstring
		}
	}

	if len(seq) >= 1 { //此是输出最后一条序列
		seq = seqTrim(seq)
		for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
			Llocation = strings.Index(seq[Llocation:], "G")
			if Llocation == -1 || aL+Llocation+28 > seqlen {
				break
			}

			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "TCAG") && strings.ContainsAny(seq[aL+Llocation+5:aL+Llocation+6], "CGT") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "GT") && strings.ContainsAny(seq[aL+Llocation+9:aL+Llocation+10], "TCA") && strings.ContainsAny(seq[aL+Llocation+10:aL+Llocation+11], "CTG") && strings.ContainsAny(seq[aL+Llocation+11:aL+Llocation+12], "GA") && strings.ContainsAny(seq[aL+Llocation+13:aL+Llocation+14], "CA") && strings.Contains(seq[aL+Llocation+14:aL+Llocation+16], "AG") && strings.ContainsAny(seq[aL+Llocation+16:aL+Llocation+17], "CGT") && strings.ContainsAny(seq[aL+Llocation+17:aL+Llocation+18], "TC") && strings.ContainsAny(seq[aL+Llocation+21:aL+Llocation+22], "CTG") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "CT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
				fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			} else if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "TCAG") && strings.ContainsAny(seq[aL+Llocation+5:aL+Llocation+6], "CT") && strings.Contains(seq[aL+Llocation+6:aL+Llocation+16], "TTCTCGAAAG") && strings.ContainsAny(seq[aL+Llocation+16:aL+Llocation+17], "CG") && strings.Contains(seq[aL+Llocation+17:aL+Llocation+18], "T") && strings.ContainsAny(seq[aL+Llocation+18:aL+Llocation+19], "AT") && strings.ContainsAny(seq[aL+Llocation+19:aL+Llocation+20], "AT") && strings.ContainsAny(seq[aL+Llocation+21:aL+Llocation+22], "CT") && strings.Contains(seq[aL+Llocation+22:aL+Llocation+23], "C") && strings.ContainsAny(seq[aL+Llocation+23:aL+Llocation+24], "GAT") && strings.ContainsAny(seq[aL+Llocation+24:aL+Llocation+25], "ACG") && strings.ContainsAny(seq[aL+Llocation+25:aL+Llocation+26], "TA") && strings.Contains(seq[aL+Llocation+26:aL+Llocation+28], "TA") {
				fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			Llocation = aL + Llocation + 1
			aL = Llocation //a用于累加每一次循环,L的位置
		}
		for {
			Flocation = strings.Index(seq[Flocation:], "G")
			if Flocation == -1 || aF+Flocation+26 > seqlen {
				break
			}
			if strings.Contains(seq[aF+Flocation+1:aF+Flocation+26], "TCAGCTTAACGAAGCATCGTGCGTA") {
				fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aF+Flocation+1, seq[aF+Flocation:aF+Flocation+26])
			}
			Flocation = aF + Flocation + 1
			aF = Flocation //a用于累加每一次循环,F的位置
		}
		for {
			Mlocation = strings.Index(seq[Mlocation:], "M")
			if Mlocation == -1 || aM+Mlocation+27 > seqlen {
				break
			}

			if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+27], "TCAGCGTGTCGTCAGCTCGCCTCGCT") {
				fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
			} else if strings.Contains(seq[aM+Mlocation+1:aM+Mlocation+27], "TCAGCTGAACGTCAGTTGTGCGCGTC") {
				fmt.Printf("%s\tTtsI\t%d\t%s\n", seq_name, aM+Mlocation+1, seq[aM+Mlocation:aM+Mlocation+27])
			}

			Mlocation = aM + Mlocation + 1
			aM = Mlocation //a用于累加每一次循环,F的位置
		}

		seq = ""
		Llocation = 0
		aL = 0
		Flocation = 0
		aF = 0
		Mlocation = 0
		aM = 0

	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

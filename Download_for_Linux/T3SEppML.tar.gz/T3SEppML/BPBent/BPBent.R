library('e1071')
load('./BPBent/BPBent.Rdata')
testdata <- read.delim('SeqMatrix.txt',head=TRUE)
testall <- subset(testdata,select=c(-prot))
Nametestall <- subset(testdata,select=c(prot))
test3 <- testall
NameTest <- Nametestall
pred <- predict(bpbent,test3,decision.values = TRUE)
values<-attr(pred,"decision.values")
Lst <- list(NameTest,values)
write.table(Lst,file="values.csv")

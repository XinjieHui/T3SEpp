//USAGE: ./featureExt  fasta_file  >Feature_FILE

package main

import (
	"bufio"
	"fmt"
	"io"
	"os"

	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	fastafilename := os.Args[1]
	fastafile, openfastaErr := os.Open(fastafilename)
	if openfastaErr != nil {
		fmt.Printf("打开%s错误", fastafilename)
	}
	defer fastafile.Close()
	fastaReader := bufio.NewReader(fastafile)
	var seqname, seq string
	var firstline []string
	//	for i := 1; i <= 20; i++ {
	//		firstline = append(firstline, amino(i))
	//	}
	//	for i := 1; i <= 20; i++ {
	//		for j := 1; j <= 20; j++ {
	//			firstline = append(firstline, amino(i)+amino(j))
	//		}
	//	}
	firstline = append(firstline, "hydrophobic", "S", "alcohol", "polar", "aliphatic", "aromatic", "SS", "W", "V", "F", "N", "bulky", "small", "PS", "L", "SA", "P", "SP", "AS", "WL", "LV", "TS", "SN", "NT", "ST", "FI", "tiny", "NI", "Y", "IV")

	for _, s := range firstline {
		fmt.Printf("\t%s", s)
	}
	fmt.Printf("\tclass")
	fmt.Printf("\n")
	for {
		fastaraw, readfastaErr := fastaReader.ReadString('\n')
		fastaraw = seqTrim(fastaraw)
		if len(fastaraw) > 0 {
			if strings.Contains(fastaraw, ">") && len(seq) > 1 {
				countmaps := make(map[string]int)
				for i, r := range seq {
					countmaps[string(r)] = countmaps[string(r)] + 1
					if i < len(seq)-1 {
						countmaps[string(r)+seq[i+1:i+2]] = countmaps[string(r)+seq[i+1:i+2]] + 1
					}
				}
				for _, s := range firstline {
					if len(s) == 1 {
						fmt.Printf("%.3f\t", float32(countmaps[s])/100)
					} else if len(s) == 2 {
						fmt.Printf("%.3f\t", float32(countmaps[s])/99)
					} else if len(s) > 2 {
						s = aminoname(s)
						aminoblocks := strings.Split(s, "/")
						var sumcounts int
						for _, aminoblock := range aminoblocks {
							sumcounts = sumcounts + countmaps[aminoblock]
						}
						fmt.Printf("%.3f\t", float32(sumcounts)/100)
					}
				}
				if strings.Contains(seqname, "pos") {
					fmt.Printf("\tpos")
				} else if strings.Contains(seqname, "neg") {
					fmt.Printf("\tneg")
				}
				seq = ""
				fmt.Printf("\n")
			}
			if strings.Contains(fastaraw, ">") {
				seqname = fastaraw
				fmt.Printf("%s\t", seqname[1:])
			} else {
				seq = seq + fastaraw
			}
		}
		if readfastaErr == io.EOF {
			if len(seq) > 1 {
				countmaps := make(map[string]int)
				for i, r := range seq {
					countmaps[string(r)] = countmaps[string(r)] + 1
					if i < len(seq)-1 {
						countmaps[string(r)+seq[i+1:i+2]] = countmaps[string(r)+seq[i+1:i+2]] + 1
					}
				}
				for _, s := range firstline {
					if len(s) == 1 {
						fmt.Printf("%.3f\t", float32(countmaps[s])/100)
					} else if len(s) == 2 {
						fmt.Printf("%.3f\t", float32(countmaps[s])/99)
					} else if len(s) > 2 {
						aminoblocks := strings.Split(s, "/")
						var sumcounts int
						for _, aminoblock := range aminoblocks {
							sumcounts = sumcounts + countmaps[aminoblock]
						}
						fmt.Printf("%.3f\t", float32(sumcounts)/100)
					}
				}
				if strings.Contains(seqname, "pos") {
					fmt.Printf("\tpos")
				} else if strings.Contains(seqname, "neg") {
					fmt.Printf("\tneg")
				}
				seq = ""
				fmt.Printf("\n")
			}
			break
		}
	}

}

func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}
func amino(i int) (s string) {
	if i == 1 {
		s = "A"
	} else if i == 2 {
		s = "R"
	} else if i == 3 {
		s = "N"
	} else if i == 4 {
		s = "D"
	} else if i == 5 {
		s = "C"
	} else if i == 6 {
		s = "Q"
	} else if i == 7 {
		s = "E"
	} else if i == 8 {
		s = "G"
	} else if i == 9 {
		s = "H"
	} else if i == 10 {
		s = "I"
	} else if i == 11 {
		s = "L"
	} else if i == 12 {
		s = "K"
	} else if i == 13 {
		s = "M"
	} else if i == 14 {
		s = "F"
	} else if i == 15 {
		s = "P"
	} else if i == 16 {
		s = "S"
	} else if i == 17 {
		s = "T"
	} else if i == 18 {
		s = "W"
	} else if i == 19 {
		s = "Y"
	} else if i == 20 {
		s = "V"
	}
	return s

}

func aminoname(name string) (s string) {
	if name == "aliphatic" {
		s = "I/V/L"
	} else if name == "aromatic" {
		s = "Y/H/W/F"
	} else if name == "hydrophobic" {
		s = "W/F/Y/M/L/I/V/A/C/T/H"
	} else if name == "alcohol" {
		s = "S/T"
	} else if name == "polar" {
		s = "D/E/H/K/N/Q/R/S/T"
	} else if name == "tiny" {
		s = "A/G/C/S"
	} else if name == "small" {
		s = "A/G/C/S/V/N/D/T/P"
	} else if name == "bulky" {
		s = "E/F/I/K/L/M/Q/R/W/Y"
	} else if name == "positively" {
		s = "K/R/H"
	} else if name == "negatively" {
		s = "D/E"
	} else if name == "charged" {
		s = "D/E/K/R/H"
	}
	return s
}

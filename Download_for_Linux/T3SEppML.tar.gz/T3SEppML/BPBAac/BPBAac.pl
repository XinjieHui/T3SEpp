#! /usr/bin/perl

# USAGE: perl  BPBAac.pl  FASTA_SEQ_With_100_aa

my $infile1 = "./BPBAac/PosMatrix.txt";
my $infile2 = "./BPBAac/NegMatrix.txt";
my $infile3 = $ARGV[0]; #Input Sequence FASTA file
my $coord = '';
my %posFreq = ();
my %negFreq = ();
my $posVector = '';
my $negVector = '';
my $prot = '';
my $seq = '';
my @seq = [];

open(IN1,"$infile1")||die"Cannot open $infile1!\n";
while(<IN1>){
  if(/^(\S+)\t(\S+)/){
    $coord = $1;
    $posFreq{$coord} = $2;
  }
}
close(IN1);

open(IN2,"$infile2")||die"Cannot open $infile2!\n";
while(<IN2>){
  if(/^(\S+)\t(\S+)/){
    $coord = $1;
    $negFreq{$coord} = $2;  
  }
}
close(IN2);

open(OUT1,">SeqMatrix.txt")||die"Cannot open 'SeqMatrix.txt'!\n";
open(IN3,"$infile3")||die"Cannot open $infile3!\n";
for(my $i=1; $i<=100;$i++){
  $posVector = $posVector."\tp".$i;
  $negVector = $negVector."\tn".$i;  
}
print OUT1 "prot",$posVector,$negVector,"\n";

while(<IN3>){
  if(/^\>(\S+)/){
    $prot = $1; 
  } elsif(/(\S+)/){
    $seq = $1;
    @seq = split(//,$seq);
    $posVector = '';
    $negVector = '';
    for(my $i=0;$i<@seq;$i++){
      $coord = $seq[$i].$i;
      $posVector = $posVector."\t".$posFreq{$coord};
      $negVector = $negVector."\t".$negFreq{$coord};
    }
    print OUT1 $prot;
    print OUT1 $posVector,$negVector;
    print OUT1 "\n";
  }
}
close(IN3);
close(OUT1);

system "Rscript ./BPBAac/BPBAac.R";

my $name = '';
my $svm = 0;

open(IN,"values.csv")||die"Cannot open values.csv!";
open(OUT,">BPBAac.out.csv")||die"Cannot open 'BPBAac.out.csv'!";
print OUT "prot", ",","SVM-Value",",","T3S protein or not","\n";
while(<IN>){
 if(/\"(\d+)\"\s\s*\"(.*)\"\s\s*(\S+)/){
  $name = $2;
  $svm = $3 +1 -1;
   if($svm>0){
      print OUT $name,",", $svm, ",","1","\n";
     }
   else{
      print OUT $name,",", $svm, ",","0","\n";        
     }
 }
}
close(IN);
close(OUT);

#system "rm ./modules/T3SEppML0/SeqMatrix.txt";
#system "rm ./modules/T3SEppML0/values.csv";

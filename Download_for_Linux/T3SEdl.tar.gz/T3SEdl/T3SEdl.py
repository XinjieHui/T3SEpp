# -*- coding: utf-8 -*-
"""
Create at @Time    : 2019-03-16 01:01
@author: MX

"""
from keras.models import load_model
import numpy as np
import pandas as pd
import argparse
from tkinter import _flatten

def BLosum_encode(data):
    Blosum = pd.read_table('BLOSUM62_matrix.txt',sep='\t',index_col=0)
    # alphabet = 'ACDEFGHIKLMNPQRSTVWY'
    sample_encode = []
    for char in data:
        one_char = Blosum[char].data
        sample_encode.append(one_char)
    sample_encode = np.array(sample_encode)
    sample_encode = list(sample_encode.flatten())
    return sample_encode


def onehot_encode(data):
    alphabet = 'ACDEFGHIKLMNPQRSTVWY'
    # define a mapping of chars to integers
    char_to_int = dict((c, i) for i, c in enumerate(alphabet))
    int_to_char = dict((i, c) for i, c in enumerate(alphabet))
    # integer encode input data
    integer_encoded = [char_to_int[char] for char in data]
    #print(integer_encoded)
    # one hot encode
    onehot_encoded = list()
    for value in integer_encoded:
       letter = [0 for _ in range(len(alphabet))]
       letter[value] = 1
       onehot_encoded.append(letter)
    onehot_encoded = np.array(onehot_encoded)
    onehot_encoded = list(onehot_encoded.flatten())
    return onehot_encoded


def loaddata(data_file):

    with open(data_file,'r')  as file:
        lines = file.readlines()
    i = 1
    data = []
    for line in lines:
        if i % 2 == 0:
            line = line.strip('\n')
            data.append(line)
        i += 1
    index = []
    for line in lines:
        if i%2 != 0:
            line = line.lstrip('>')
            line = line.strip('\n')
            index.append(line)
        i += 1
    return data, index



def all_data_processing(flag, data):
    #  data encoding
    data_encode = []

    if flag == 1:

        for i in data:
            try:
                data_encode_sample = onehot_encode(i)
                data_encode.append(data_encode_sample)
            except KeyError:
                pass
    else:
        for j in data:
            try:
                data_encode_sample = BLosum_encode(j)
                data_encode.append(data_encode_sample)
            except KeyError:
                pass
    X = np.array(data_encode)
    return X

def result_tocsv(index, y_test, y_class):
    #result to csv
    y_class = y_class.tolist()
    y_test = y_test.tolist()
    y_test = list(_flatten(y_test))
    y_class = list(_flatten(y_class))

    result = [index, y_test, y_class]
    result_data = pd.DataFrame({'ID':result[0], 'Score':result[1], 'Class(1:Y, 0:N)':result[2]})
    result_data.to_csv('result.csv', sep=',', index=None, encoding='utf-8')

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--testset',  help=".txt file with test data")
    parser.add_argument('-m', '--model', help="model choose string 'CNN_LSTM' or DNN ")
    args = parser.parse_args()

    model = args.model
    data_file = args.testset
    print('loading data ...')
    data, index = loaddata(data_file)


    print('data predicting ...')

    if model == "CNN_LSTM":
        model_CNN = load_model('models/model-ep088-loss0.210-val_acc0.936.h5')
        flag = 0
        x_test = all_data_processing(flag, data)

        x_test = np.reshape(x_test,(x_test.shape[0],20,100))

        y_test = model_CNN.predict(x_test)
        Y_test_negpos = np.array(list(map(lambda x: 1 - x, y_test)))
        Y_test_merge = np.column_stack((Y_test_negpos, y_test))  # 组合两者的概率
        y_class = np.argmax(Y_test_merge, axis=1)

    elif model == 'DNN':
        model_DNN = load_model('models/model-ep026-loss0.000-val_acc0.892.h5')
        flag = 1
        x_test = all_data_processing(flag, data)

        y_test = model_DNN.predict(x_test)
        y_class = model_DNN.predict_classes(x_test)

    else:
        assert model == 'CNN_LSTM or DNN' 'Error in model selection'
    print('complete !!!')
    print(len(index), y_test.shape, y_class.shape)
    result_tocsv(index, y_test, y_class)







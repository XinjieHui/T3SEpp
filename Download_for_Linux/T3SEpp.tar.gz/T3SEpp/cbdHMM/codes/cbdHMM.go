//cbdHMM.exe   .fasta文件
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strconv"
	"strings"
)

func main() {
	if len(os.Args) <= 1 {
		fmt.Printf("There is no input file!\n")
		return
	}
	inputFileName := os.Args[1]
	inputFile, openErr := os.Open(inputFileName)
	if openErr != nil {
		fmt.Printf("Error happened in opening %s\n", inputFileName)
		return
	}
	defer inputFile.Close()
	inputReader := bufio.NewReader(inputFile)
	var seq_name, seq string
	var seqlen int
	Llocation := 0
	aL := 0
	Flocation := 0
	aF := 0
	Mlocation := 0
	aM := 0
	for {
		inputstring, readErr := inputReader.ReadString('\n')
		inputstring = seqTrim(inputstring)

		pat, _ := regexp.MatchString("^>", inputstring) //也可以：pat := strings.Contains(inputstring, ">")
		seqlen = len(seq)
		if pat && seqlen >= 1 {
			seq = seqTrim(seq)
			var indexs string = "-"
			var sequence string = "-"
			for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
				Llocation = strings.Index(seq[Llocation:], "L")
				if Llocation == -1 || aL+Llocation+8 > seqlen || aL+Llocation+1 > 90 {
					break
				}
				if aL+Llocation+1 >= 21 {
					if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "L") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "VAGQT") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "I") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "VEFSY") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "A") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "LV") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "V") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "LAN") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "A") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "Q") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "L") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "D") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "I") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "R") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
					} else if strings.Contains(seq[aL+Llocation+3:aL+Llocation+4], "I") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "L") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
						sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+7]
					}
				}
				Llocation = aL + Llocation + 1
				aL = Llocation //a用于累加每一次循环,L的位置
			}
			for {
				Flocation = strings.Index(seq[Flocation:], "F")
				if Flocation == -1 || aF+Flocation+8 > seqlen || aF+Flocation+1 > 90 {
					break
				}
				if aF+Flocation+1 >= 21 {
					if strings.Contains(seq[aF+Flocation+4:aF+Flocation+5], "I") && strings.Contains(seq[aF+Flocation+7:aF+Flocation+8], "V") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
						sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
					} else if strings.Contains(seq[aF+Flocation+4:aF+Flocation+5], "V") && strings.Contains(seq[aF+Flocation+7:aF+Flocation+8], "H") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
						sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
					} else if strings.Contains(seq[aF+Flocation+5:aF+Flocation+6], "L") && strings.ContainsAny(seq[aF+Flocation+7:aF+Flocation+8], "W") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
						sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
					} else if strings.Contains(seq[aF+Flocation+5:aF+Flocation+6], "V") && strings.ContainsAny(seq[aF+Flocation+7:aF+Flocation+8], "I") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
						sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
					}
				}

				Flocation = aF + Flocation + 1
				aF = Flocation //a用于累加每一次循环,F的位置
			}
			for {
				Mlocation = strings.Index(seq[Mlocation:], "M")
				if Mlocation == -1 || aM+Mlocation+8 > seqlen || aM+Mlocation+1 > 90 {
					break
				}
				if aM+Mlocation+1 >= 21 {
					if strings.Contains(seq[aM+Mlocation+5:aM+Mlocation+6], "V") && strings.Contains(seq[aM+Mlocation+7:aM+Mlocation+8], "Q") {
						indexs = strings.Replace(indexs, "-", "", -1)
						sequence = strings.Replace(sequence, "-", "", -1)
						indexs = indexs + "/" + strconv.Itoa(aM+Mlocation+1)
						sequence = sequence + "/" + seq[aM+Mlocation:aM+Mlocation+8]

					}
				}

				Mlocation = aM + Mlocation + 1
				aM = Mlocation //a用于累加每一次循环,F的位置
			}
			seqnamesplit := strings.Split(seq_name, " ")
			fmt.Printf("%s\t%s\t%s\n", seqnamesplit[0], strings.Replace(indexs, "/", "", 1), strings.Replace(sequence, "/", "", 1))
			seq = ""
			Llocation = 0
			aL = 0
			Flocation = 0
			aF = 0
			Mlocation = 0
			aM = 0

		}
		if pat {
			seq_name = inputstring[1:]
		}

		if !pat {
			seq = seq + inputstring
		}

		if readErr == io.EOF {
			break
		}
	}

	seqlen = len(seq)
	if len(seq) >= 1 { //此是输出最后一条序列
		var indexs string = "-"
		var sequence string = "-"
		for { //先循环所有L的位置，判断有无符合条件，下一个循环再找所有F的位置
			Llocation = strings.Index(seq[Llocation:], "L")
			if Llocation == -1 || aL+Llocation+8 > seqlen || aL+Llocation+1 > 90 {
				break
			}
			if aL+Llocation+1 >= 21 {
				if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "L") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "VAGQT") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "I") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "VEFSY") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "A") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "LV") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+4:aL+Llocation+5], "V") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "LAN") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "A") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "Q") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "L") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "D") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+5:aL+Llocation+6], "I") && strings.ContainsAny(seq[aL+Llocation+7:aL+Llocation+8], "R") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+8]
				} else if strings.Contains(seq[aL+Llocation+3:aL+Llocation+4], "I") && strings.ContainsAny(seq[aL+Llocation+6:aL+Llocation+7], "L") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aL+Llocation+1)
					sequence = sequence + "/" + seq[aL+Llocation:aL+Llocation+7]
				}
			}
			Llocation = aL + Llocation + 1
			aL = Llocation //a用于累加每一次循环,L的位置
		}
		for {
			Flocation = strings.Index(seq[Flocation:], "F")
			if Flocation == -1 || aF+Flocation+8 > seqlen || aF+Flocation+1 > 90 {
				break
			}
			if aF+Flocation+1 >= 21 {

				if strings.Contains(seq[aF+Flocation+4:aF+Flocation+5], "I") && strings.Contains(seq[aF+Flocation+7:aF+Flocation+8], "V") {

					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
					sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
				} else if strings.Contains(seq[aF+Flocation+4:aF+Flocation+5], "V") && strings.Contains(seq[aF+Flocation+7:aF+Flocation+8], "H") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
					sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
				} else if strings.Contains(seq[aF+Flocation+5:aF+Flocation+6], "L") && strings.ContainsAny(seq[aF+Flocation+7:aF+Flocation+8], "W") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
					sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
				} else if strings.Contains(seq[aF+Flocation+5:aF+Flocation+6], "V") && strings.ContainsAny(seq[aF+Flocation+7:aF+Flocation+8], "I") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aF+Flocation+1)
					sequence = sequence + "/" + seq[aF+Flocation:aF+Flocation+8]
				}
			}

			Flocation = aF + Flocation + 1
			aF = Flocation //a用于累加每一次循环,F的位置
		}
		for {
			Mlocation = strings.Index(seq[Mlocation:], "M")
			if Mlocation == -1 || aM+Mlocation+8 > seqlen || aM+Mlocation+1 > 90 {
				break
			}
			if aM+Mlocation+1 >= 21 {
				if strings.Contains(seq[aM+Mlocation+5:aM+Mlocation+6], "V") && strings.Contains(seq[aM+Mlocation+7:aM+Mlocation+8], "Q") {
					indexs = strings.Replace(indexs, "-", "", -1)
					sequence = strings.Replace(sequence, "-", "", -1)
					indexs = indexs + "/" + strconv.Itoa(aM+Mlocation+1)
					sequence = sequence + "/" + seq[aM+Mlocation:aM+Mlocation+8]

				}
			}

			Mlocation = aM + Mlocation + 1
			aM = Mlocation //a用于累加每一次循环,F的位置
		}
		seqnamesplit := strings.Split(seq_name, " ")
		fmt.Printf("%s\t%s\t%s\n", seqnamesplit[0], strings.Replace(indexs, "/", "", 1), strings.Replace(sequence, "/", "", 1))
		seq = ""
		Llocation = 0
		aL = 0
		Flocation = 0
		aF = 0
		Mlocation = 0
		aM = 0
	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

//USAGE: ./SeqAac  Feature_FILE  >RESULT

package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strconv"

	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	matixfilename := os.Args[1]
	matixfile, openmatixErr := os.Open(matixfilename)
	if openmatixErr != nil {
		fmt.Printf("打开%s错误", matixfilename)
	}
	defer matixfile.Close()
	matixReader := bufio.NewReader(matixfile)
	var firstlines []string
	aminomaps := make(map[string]int)
	for {
		matixraw, readmatixErr := matixReader.ReadString('\n')
		matixraw = seqTrim(matixraw)
		if strings.Contains(matixraw, "hydrophobic") {
			fmt.Println(matixraw)
			matixraw = "first" + matixraw
			firstlines = strings.Split(matixraw, "\t")
			for i, s := range firstlines {
				aminomaps[s] = i //存氨基酸类别对应的序号
			}
		} else if len(matixraw) > 0 {
			lineblocks := strings.Split(matixraw, "\t")
			hydrophobic, _ := strconv.ParseFloat(lineblocks[aminomaps["hydrophobic"]], 64)
			alcohol, _ := strconv.ParseFloat(lineblocks[aminomaps["alcohol"]], 64)
			Y, _ := strconv.ParseFloat(lineblocks[aminomaps["Y"]], 64)
			W, _ := strconv.ParseFloat(lineblocks[aminomaps["W"]], 64)
			polar, _ := strconv.ParseFloat(lineblocks[aminomaps["polar"]], 64)
			aromatic, _ := strconv.ParseFloat(lineblocks[aminomaps["aromatic"]], 64)
			aliphatic, _ := strconv.ParseFloat(lineblocks[aminomaps["aliphatic"]], 64)
			ST, _ := strconv.ParseFloat(lineblocks[aminomaps["ST"]], 64)
			SA, _ := strconv.ParseFloat(lineblocks[aminomaps["SA"]], 64)
			LV, _ := strconv.ParseFloat(lineblocks[aminomaps["LV"]], 64)

			if hydrophobic >= 0.47 {
				if alcohol < 0.16 {
					if Y >= 0.005 {
						if polar < 0.48 {
							if ST < 0.015 {
								fmt.Printf("%s\t0", matixraw)
							} else {
								fmt.Printf("%s\t1", matixraw)
							}
						} else {
							if W >= 0.015 {
								fmt.Printf("%s\t0", matixraw)
							} else {
								if SA < 0.015 {
									if LV >= 0.005 {
										fmt.Printf("%s\t0", matixraw)
									} else {
										fmt.Printf("%s\t1", matixraw)
									}
								} else {
									fmt.Printf("%s\t1", matixraw)
								}
							}

						}
					} else {
						if aliphatic >= 0.24 {
							fmt.Printf("%s\t0", matixraw)
						} else {
							fmt.Printf("%s\t1", matixraw)
						}
					}
				} else {
					if hydrophobic >= 0.55 {
						if aromatic >= 0.065 {
							fmt.Printf("%s\t0", matixraw)
						} else {
							fmt.Printf("%s\t1", matixraw)
						}
					} else {
						fmt.Printf("%s\t1", matixraw)
					}
				}
			} else {
				if alcohol < 0.14 {
					if W >= 0.015 {
						fmt.Printf("%s\t0", matixraw)
					} else {
						fmt.Printf("%s\t1", matixraw)
					}
				} else {
					fmt.Printf("%s\t1", matixraw)
				}
			}
			fmt.Printf("\n")
		}
		if readmatixErr == io.EOF {

			break
		}
	}

}

func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}
func amino(i int) (s string) {
	if i == 1 {
		s = "A"
	} else if i == 2 {
		s = "R"
	} else if i == 3 {
		s = "N"
	} else if i == 4 {
		s = "D"
	} else if i == 5 {
		s = "C"
	} else if i == 6 {
		s = "Q"
	} else if i == 7 {
		s = "E"
	} else if i == 8 {
		s = "G"
	} else if i == 9 {
		s = "H"
	} else if i == 10 {
		s = "I"
	} else if i == 11 {
		s = "L"
	} else if i == 12 {
		s = "K"
	} else if i == 13 {
		s = "M"
	} else if i == 14 {
		s = "F"
	} else if i == 15 {
		s = "P"
	} else if i == 16 {
		s = "S"
	} else if i == 17 {
		s = "T"
	} else if i == 18 {
		s = "W"
	} else if i == 19 {
		s = "Y"
	} else if i == 20 {
		s = "V"
	}
	return s

}

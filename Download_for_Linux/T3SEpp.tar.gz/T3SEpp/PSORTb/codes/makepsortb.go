package main

import (
	"bufio"
	"fmt"
	"io"
	"os"

	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	fastafilename := os.Args[1]
	fastafile, openfastaErr := os.Open(fastafilename)
	if openfastaErr != nil {
		fmt.Printf("打开%s错误", openfastaErr)
	}
	defer fastafile.Close()
	fastaReader := bufio.NewReader(fastafile)

	for {
		fastaraw, readfastaErr := fastaReader.ReadString('\n')
		fastaraw = seqTrim(fastaraw)
		if strings.Contains(fastaraw, ">") {
			seqname := strings.Split(fastaraw[1:], " ")
			fmt.Printf("%s", seqname[0])
			for i := 0; i < 2; i++ {
				fmt.Printf("\t-")
			}
			fmt.Printf("\n")
		}
		if readfastaErr == io.EOF {
			break
		}
	}

}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

#! /usr/bin/perl

#USAGE: perl  T3SEppML.pl  RAW_FASTA_SEQ_FILE

my $prot = '';
my $rl = 0;
my $seq = '';
my $str = '';
my $testProtFile = $ARGV[0];

open(IN,"$testProtFile")||die"Cannot open 'FASTA_SEQ_FILE'!\n";
open(OUT1,">N100.fa")||die"Cannot open 'N100'!\n";
while(<IN>){
  if(/^\>(\S+)/){
    $prot = $1;
    if(length($seq) > 100){
      print OUT1 ">",$prot1,"\n";
      $str = substr($seq,1,100);
      $str =~ s/[^AaCcDdEeFfGgHhIiKkLlMmNnPpQqRrSsTtVvWwYy]/A/g;
      print OUT1 $str,"\n";
    } elsif(length($seq) == 0){    
    } else {
      $rl = 100 - length($seq) + 1;
      print OUT1 ">",$prot1,"\n";
      $str = substr($seq,1,(length($seq) - 1));
      $str =~ s/[^AaCcDdEeFfGgHhIiKkLlMmNnPpQqRrSsTtVvWwYy]/A/g;
      print OUT1 $str;
      for(my $i=1;$i<=$rl;$i++){
        print OUT1 "A";
      }
      print OUT1 "\n";
    }
    $seq = '';
    $prot1 = $prot;
  }elsif(/(\S+)/){
    $seq = $seq.$1;
  }
}
close(IN);

if(length($seq) > 100){
   print OUT1 ">",$prot1,"\n";
   $str = substr($seq,1,100);
   $str =~ s/[^AaCcDdEeFfGgHhIiKkLlMmNnPpQqRrSsTtVvWwYy]/A/g;
   print OUT1 $str,"\n";
} elsif(length($seq) == 0){    
} else {
   $rl = 100 - length($seq) + 1;
   print OUT1 ">",$prot1,"\n";
   $str = substr($seq,1,(length($seq) - 1));
   $str =~ s/[^AaCcDdEeFfGgHhIiKkLlMmNnPpQqRrSsTtVvWwYy]/A/g;
   print OUT1 $str;
   for(my $i=1;$i<=$rl;$i++){
     print OUT1 "A";
   }
   print OUT1 "\n";
}
close(OUT1);

system "perl BPBAac/BPBAac.pl N100.fa";
system "perl BPBent/BPBent.pl N100.fa";
system "perl T3_MM/T3MM.pl N100.fa";
system "./SeqAac/bin/featureExt N100.fa >SeqAacFeatures.txt";
system "./SeqAac/bin/SeqAac SeqAacFeatures.txt >SeqAac.out0.txt";
system "rm SeqAacFeatures.txt";

open(IN2,"SeqAac.out0.txt")||die"Cannot open 'SeqAac.out0.txt'!";
open(OUT2,">SeqAac.out.csv")||die"Cannot open 'SeqAac.out.csv'!";
print OUT2 "prot",",","T3SE or not","\n";
while(<IN2>){
  if(/^(\S+)(.*)\t(.*)\t(\d)$/){
    print OUT2 $1,",",$4,"\n";
  }
}
close(IN2);
close(OUT2);

system "rm SeqAac.out0.txt";

my %BPBAacVal = ();
my %BPBAac = ();
my %BPBentVal = ();
my %BPBent = ();
my %SeqAacVal = ();
my %SeqAac = ();
my %T3MMVal = ();
my %T3MM = ();

open(BPBAAC,"BPBAac.out.csv")||die"Cannot open 'BPBAac.out.csv'!\n";
while(<BPBAAC>){
  if(/^(.*)\,(.*)\,(\d+)$/){
      $prot = $1;
      $BPBAacVal{$prot} = $2;
      $BPBAac{$prot} = $3;  
  }
}
close(BPBAAC);


open(BPBENT,"BPBent.out.csv")||die"Cannot open 'BPBent.out.csv'!\n";
while(<BPBENT>){
  if(/^(.*)\,(.*)\,(\d+)$/){
      $prot = $1;
      $BPBentVal{$prot} = $2;
      $BPBent{$prot} = $3;
  }       
}
close(BPBENT);


open(SEQAAC,"SeqAac.out.csv")||die"Cannot open 'SeqAac.out.csv'!\n";
while(<SEQAAC>){
  if(/^(.*)\,(\d+)$/){
      $prot = $1;
      $SeqAacVal{$prot} = $2;
      $SeqAac{$prot} = $2;
  }    
}
close(SEQAAC);

system("python3  T3SEdl/T3SEdl.py  -t  N100.fa  -m  DNN");
system("mv result.csv T3SEdnn.out.csv");
system("python3  T3SEdl/T3SEdl.py  -t  N100.fa  -m  CNN_LSTM");
system("mv result.csv T3SErnn.out.csv");
system("perl T3SEdl/mergeDL.pl T3SEdnn.out.csv T3SErnn.out.csv >T3SEdl.out.txt");

open(T3SEDL,"T3SEdl.out.txt")||die"Cannot open 'T3SEdl.out.txt'!\n";
while(<T3SEDL>){
  if(/^(\S+)\t(\S+)\t(\S+)/){
    $prot = $1;
    $T3SEdlVal{$prot} = $2;
    $T3SEdl{$prot} = $3;
  }
}
close(T3SEDL);

open(T3SEMLOUT,">T3SEppML.out.txt")||die"Cannot open 'T3SEppML.out.txt'!\n";
print T3SEMLOUT "prot\tSeqAac|BPBAac|BPBent|T3_MM|T3SEdnn|T3SErnn score\tSeqAac|BPBAac|BPBent|T3_MM|T3SEdnn|T3SErnn\n";
open(T3MM,"T3_MM.out.csv")||die"Cannot open 'T3_MM.out.csv'!\n";
while(<T3MM>){
  if(/^(.*)\,(.*)\,(\d+)$/){
      $prot = $1;
      $T3MMVal{$prot} = $2;
      $T3MM{$prot} = $3;
      print T3SEMLOUT $prot,"\t",$SeqAacVal{$prot},"|",$BPBAacVal{$prot},"|",$BPBentVal{$prot},"|",$T3MMVal{$prot},"|",$T3SEdlVal{$prot},"\t",$SeqAac{$prot},"|",$BPBAac{$prot},"|",$BPBent{$prot},"|",$T3MM{$prot},"|",$T3SEdl{$prot},"\n";
  } 
}
close(T3MM);
close(T3SEMLOUT);

system("rm SeqMatrix.txt");
system("rm values.csv");
system("rm N100.fa");
system("rm SeqAac.out.csv");
system("rm BPBAac.out.csv");
system("rm BPBent.out.csv");
system("rm T3_MM.out.csv");
system("rm T3SEdnn.out.csv");
system("rm T3SErnn.out.csv");
system("rm T3SEdl.out.txt");

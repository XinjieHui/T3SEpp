// out
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strconv"

	"strings"
)

func main() {
	T3SEppMLfile, openT3SEppMLErr := os.Open("T3SEppML.out.txt")
	if openT3SEppMLErr != nil {
		fmt.Printf("打开T3SEppML.out.txt错误")
		return
	}

	T3SEppMLReader := bufio.NewReader(T3SEppMLfile)
	var firstlines string
	firstlines = "prot" + "\t" + "T3SEppML"
	prot_modulemaps := make(map[string][]string) //存每个prot对于module的N或者Y值

	for {
		T3SEppMLraw, readT3SEppMLErr := T3SEppMLReader.ReadString('\n')
		T3SEppMLraw = seqTrim(T3SEppMLraw)

		if strings.Contains(T3SEppMLraw, "SeqAac") {
			continue
		}
		if len(T3SEppMLraw) > 0 {
			lineblocks := strings.Split(T3SEppMLraw, "\t")
			scoreblocks := strings.Split(lineblocks[2], "|")
			sum := 0
			for _, scoreblock := range scoreblocks {
				if scoreblock == "1" {
					sum++
				}
			}
			if sum >= 3 {
				prot_modulemaps[lineblocks[0]] = append(prot_modulemaps[lineblocks[0]], "1")
			} else {
				prot_modulemaps[lineblocks[0]] = append(prot_modulemaps[lineblocks[0]], "0")
			}
		}
		if readT3SEppMLErr == io.EOF {
			break
		}

	}
	T3SEppMLfile.Close()
	flBlastfile, openflBlastfileErr := os.Open("flBlast.out.txt")
	if openflBlastfileErr != nil {
		fmt.Printf("打开flBlast.out.txt错误")
		return
	}

	flBlastReader := bufio.NewReader(flBlastfile)
	firstlines = firstlines + "\tflBlast"
	flBlastmaps := make(map[string]string)
	for {
		flBlastraw, readflBlastErr := flBlastReader.ReadString('\n')
		flBlastraw = seqTrim(flBlastraw)
		if strings.Contains(flBlastraw, "Query") {
			continue
		}
		if len(flBlastraw) > 0 {
			lineblocks := strings.Split(flBlastraw, "\t")
			if strings.Contains(lineblocks[5], "-") {
				// flBlastmaps[lineblocks[0]] = "0"
			} else {
				flBlastmaps[lineblocks[0]] = "1"
			}
		}
		if readflBlastErr == io.EOF {
			break
		}
	}
	for prot, _ := range prot_modulemaps {
		_, ok := flBlastmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}

	flBlastfile.Close()

	sigHMMfile, opensigHMMfileErr := os.Open("sigHMM.out.txt")
	if opensigHMMfileErr != nil {
		fmt.Printf("打开sigHMM.out.txt错误")
		return
	}
	defer sigHMMfile.Close()
	sigHMMReader := bufio.NewReader(sigHMMfile)
	firstlines = firstlines + "\tsigHMM"
	sigHMMmaps := make(map[string]string)
	for {
		sigHMMraw, readsigHMMErr := sigHMMReader.ReadString('\n')
		sigHMMraw = seqTrim(sigHMMraw)
		if len(sigHMMraw) > 0 {

			lineblocks := strings.Split(sigHMMraw, "\t")
			if strings.Contains(lineblocks[1], "FAM") {
				sigHMMmaps[lineblocks[0]] = "1"
			}
		}
		if readsigHMMErr == io.EOF {
			break
		}
	}
	for prot, _ := range prot_modulemaps {
		_, ok := sigHMMmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}

	sigHMMfile.Close()
	//打开处理cbdHMM文件
	cbdHMMfile, opencbdHMMfileErr := os.Open("cbdHMM.out.txt")
	if opencbdHMMfileErr != nil {
		fmt.Printf("打开cbdHMM.out.txt错误")
		return
	}
	cbdHMMReader := bufio.NewReader(cbdHMMfile)
	firstlines = firstlines + "\tcbdHMM"
	cbdHMMmaps := make(map[string]string)
	for {
		cbdHMMraw, readcbdHMMErr := cbdHMMReader.ReadString('\n')
		cbdHMMraw = seqTrim(cbdHMMraw)
		if len(cbdHMMraw) > 0 {

			lineblocks := strings.Split(cbdHMMraw, "\t")
			if !strings.Contains(lineblocks[1], "-") {
				cbdHMMmaps[lineblocks[0]] = "1"
			}
		}
		if readcbdHMMErr == io.EOF {
			break
		}
	}
	for prot, _ := range prot_modulemaps {
		_, ok := cbdHMMmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}
	cbdHMMfile.Close()

	//打开effectHMM.out文件
	effectHMMfile, openeffectHMMfileErr := os.Open("effectHMM.out.txt")
	if openeffectHMMfileErr != nil {
		fmt.Printf("打开effectHMM.out.txt错误")
		return
	}
	defer effectHMMfile.Close()
	effectHMMReader := bufio.NewReader(effectHMMfile)
	firstlines = firstlines + "\teffectHMM"
	effectHMMmaps := make(map[string]string)
	for {
		effectHMMraw, readeffectHMMErr := effectHMMReader.ReadString('\n')
		effectHMMraw = seqTrim(effectHMMraw)
		if len(effectHMMraw) > 0 {

			lineblocks := strings.Split(effectHMMraw, "\t")
			if strings.Contains(lineblocks[1], "FAM") {
				effectHMMmaps[lineblocks[0]] = "1"
			}
		}
		if readeffectHMMErr == io.EOF {
			break
		}
	}
	for prot, _ := range prot_modulemaps {
		_, ok := effectHMMmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}

	effectHMMfile.Close()
	//打开transHMM.out文件
	transHMMfile, opentransHMMfileErr := os.Open("transHMM.out.txt")
	if opentransHMMfileErr != nil {
		fmt.Printf("打开transHMM.out.txt错误")
		return
	}
	defer transHMMfile.Close()
	transHMMReader := bufio.NewReader(transHMMfile)
	firstlines = firstlines + "\ttransHMM"
	transHMMmaps := make(map[string]string)
	for {
		transHMMraw, readtransHMMErr := transHMMReader.ReadString('\n')
		transHMMraw = seqTrim(transHMMraw)
		if len(transHMMraw) > 0 {

			lineblocks := strings.Split(transHMMraw, "\t")
			if !strings.Contains(lineblocks[1], "-") {
				transHMMmaps[lineblocks[0]] = "1"
			}
		}
		if readtransHMMErr == io.EOF {
			break
		}
	}
	for prot, _ := range prot_modulemaps {
		_, ok := transHMMmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}
	transHMMfile.Close()

	//打开TMHMM.out.txt文件
	tmhmmfile, opentmhmmfileErr := os.Open("TMHMM.out.txt")
	if opentmhmmfileErr != nil {
		fmt.Printf("打开tmhmm.out.txt错误")
		return
	}
	defer tmhmmfile.Close()
	tmhmmReader := bufio.NewReader(tmhmmfile)
	firstlines = firstlines + "\tTMHMM"
	tmhmmmaps := make(map[string]string)
	for {
		tmhmmraw, readtmhmmErr := tmhmmReader.ReadString('\n')
		tmhmmraw = seqTrim(tmhmmraw)
		if strings.Contains(tmhmmraw, "#") || strings.Contains(tmhmmraw, "HELP with") {
			continue
		}
		if len(tmhmmraw) > 0 {
			tmhmmraw = strings.Replace(tmhmmraw, "          ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "         ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "        ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "       ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "      ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "     ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "    ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "   ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, "  ", "\t", -1)
			tmhmmraw = strings.Replace(tmhmmraw, " ", "\t", -1)
			lineblocks := strings.Split(tmhmmraw, "\t")
			lineblock0 := strings.Split(lineblocks[0], " ")
			protname := lineblock0[0]
			if !strings.ContainsAny(lineblocks[5], "0123456789") && lineblocks[5] != "-" {
				tmhmmmaps[protname] = "1"
			}
		}
		if readtmhmmErr == io.EOF {
			break
		}

	}
	for prot, _ := range prot_modulemaps {
		_, ok := tmhmmmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}
	tmhmmfile.Close()
	//第八模块，打开PSORTb.out.txt
	PSORTbfile, openPSORTbfileErr := os.Open("PSORTb.out.txt")
	if openPSORTbfileErr != nil {
		fmt.Printf("打开PSORTb.out.txt错误")
		return
	}
	defer PSORTbfile.Close()
	PSORTbReader := bufio.NewReader(PSORTbfile)
	firstlines = firstlines + "\tPSORTb"
	PSORTbmaps := make(map[string]string)
	for {
		PSORTbraw, readPSORTbErr := PSORTbReader.ReadString('\n')
		PSORTbraw = seqTrim(PSORTbraw)
		if strings.Contains(PSORTbraw, "Localization") {
			continue
		}
		if len(PSORTbraw) > 0 {
			lineblocks := strings.Split(PSORTbraw, "\t")
			lineblock0 := strings.Split(lineblocks[0], " ")
			protname := lineblock0[0]
			if strings.Contains(lineblocks[1], "Cytoplasmic") || lineblocks[1] == "-" {
				PSORTbmaps[protname] = "a"
			}
		}
		if readPSORTbErr == io.EOF {
			break
		}

	}
	for prot, _ := range prot_modulemaps {
		_, ok := PSORTbmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		}
	}
	PSORTbfile.Close()
	//打开SignalP.out
	SignalPfile, openSignalPfileErr := os.Open("SignalP.out.txt")
	if openSignalPfileErr != nil {
		fmt.Printf("打开SignalP.out.txt错误")
		return
	}
	defer SignalPfile.Close()
	SignalPReader := bufio.NewReader(SignalPfile)
	firstlines = firstlines + "\tSignalP"
	SignalPmaps := make(map[string]string)
	for {
		SignalPraw, readSignalPErr := SignalPReader.ReadString('\n')
		SignalPraw = seqTrim(SignalPraw)
		if strings.Contains(SignalPraw, "#") || strings.Contains(SignalPraw, "Signal peptides") {
			continue
		}
		if len(SignalPraw) > 0 {
			SignalPraw = strings.Replace(SignalPraw, "                           ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                          ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                         ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                        ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                       ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                      ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                     ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                    ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                   ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                  ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                 ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "                ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "               ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "              ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "             ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "            ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "           ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "          ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "         ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "        ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "       ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "      ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "     ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "    ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "   ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, "  ", "\t", -1)
			SignalPraw = strings.Replace(SignalPraw, " ", "\t", -1)
			lineblocks := strings.Split(SignalPraw, "\t")
			lineblock0 := strings.Split(lineblocks[0], " ")
			protname := lineblock0[0]
			Dscore, _ := strconv.ParseFloat(lineblocks[8], 64)
			if Dscore-0.42 <= 0 && lineblocks[8] != "-" {
				SignalPmaps[protname] = "A"
			}

		}
		if readSignalPErr == io.EOF {
			break
		}
	}
	SignalPfile.Close()
	for prot, _ := range prot_modulemaps {
		_, ok := SignalPmaps[prot]
		if ok {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "1")
		} else {
			prot_modulemaps[prot] = append(prot_modulemaps[prot], "0")
		}
	}
	fmt.Println(firstlines)
	for prot, _ := range prot_modulemaps {
		fmt.Printf("%s", prot)
		for i, _ := range prot_modulemaps[prot] {
			fmt.Printf("\t%s", prot_modulemaps[prot][i])
		}
		fmt.Printf("\n")
	}
}

func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

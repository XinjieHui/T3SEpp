//使用方法：tranHMM.exe              6个模式识别.exe（顺序无要求）   序列文件(DNA序列文件，调控区域既上游2000bp) >生成文件
package main

import (
	"bufio"
	"fmt"
	"io"
	//	"io/ioutil"
	"os"
	"os/exec"
	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	fastafilename := os.Args[7]
	fastafile, openfastaErr := os.Open(fastafilename)
	if openfastaErr != nil {
		fmt.Printf("打开%s错误", openfastaErr)
	}
	defer fastafile.Close()
	fastaReader := bufio.NewReader(fastafile)
	var seq string
	type info struct {
		pattern  string
		location string
		seq      string
	}
	seqname_FAMcounts := make(map[string]*info)
	var seqnamestring []string
	for {
		fastaraw, readfastaErr := fastaReader.ReadString('\n')
		fastaraw = seqTrim(fastaraw)
		if len(fastaraw) > 0 {
			if strings.Contains(fastaraw, ">") && len(seq) > 1 {

			}
			if strings.Contains(fastaraw, ">") {
				seqnamestring = append(seqnamestring, fastaraw[1:])
				seqname_FAMcounts[fastaraw[1:]] = &info{"-", "-", "-"}
			} else {
				seq = seq + fastaraw
			}
		}
		if readfastaErr == io.EOF {

			break
		}
	}

	cmd1 := exec.Command(os.Args[1], os.Args[7])
	buf1, err := cmd1.Output()
	if err != nil {
		fmt.Printf("Error: %s\n", err)
	}
	lines := strings.Split(string(buf1), "\n")
	for _, line := range lines {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}

	cmd2 := exec.Command(os.Args[2], os.Args[7])
	buf2, err2 := cmd2.Output()
	if err2 != nil {
		fmt.Printf("Error: %s\n", err2)
	}
	lines2 := strings.Split(string(buf2), "\n")
	for _, line := range lines2 {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}

	cmd3 := exec.Command(os.Args[3], os.Args[7])
	buf3, err3 := cmd3.Output()
	if err3 != nil {
		fmt.Printf("Error: %s\n", err3)
	}
	lines3 := strings.Split(string(buf3), "\n")
	for _, line := range lines3 {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}

	cmd4 := exec.Command(os.Args[4], os.Args[7])
	buf4, err4 := cmd4.Output()
	if err4 != nil {
		fmt.Printf("Error: %s\n", err4)
	}
	lines4 := strings.Split(string(buf4), "\n")
	for _, line := range lines4 {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}

	cmd5 := exec.Command(os.Args[5], os.Args[7])
	buf5, err5 := cmd5.Output()
	if err5 != nil {
		fmt.Printf("Error: %s\n", err5)
	}
	lines5 := strings.Split(string(buf5), "\n")
	for _, line := range lines5 {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}

	cmd6 := exec.Command(os.Args[6], os.Args[7])
	buf6, err6 := cmd6.Output()
	if err6 != nil {
		fmt.Printf("Error: %s\n", err6)
	}
	lines6 := strings.Split(string(buf6), "\n")
	for _, line := range lines6 {
		line = seqTrim(line)
		if len(line) > 0 {
			lineblocks := strings.Split(line, "\t")
			seqname_FAMcounts[lineblocks[0]].pattern = strings.Replace(seqname_FAMcounts[lineblocks[0]].pattern, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].location = strings.Replace(seqname_FAMcounts[lineblocks[0]].location, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].seq = strings.Replace(seqname_FAMcounts[lineblocks[0]].seq, "-", "", -1)
			seqname_FAMcounts[lineblocks[0]].pattern = seqname_FAMcounts[lineblocks[0]].pattern + "/" + lineblocks[1]
			seqname_FAMcounts[lineblocks[0]].location = seqname_FAMcounts[lineblocks[0]].location + "/" + lineblocks[2]
			seqname_FAMcounts[lineblocks[0]].seq = seqname_FAMcounts[lineblocks[0]].seq + "/" + lineblocks[3]
		}
	}
	for _, seqname := range seqnamestring {
		seqnamesplit := strings.Split(seqname, " ")
		fmt.Printf("%s\t%s\t%s\t%s\n", seqnamesplit[0], strings.Replace(seqname_FAMcounts[seqname].pattern, "/", "", 1), strings.Replace(seqname_FAMcounts[seqname].location, "/", "", 1), strings.Replace(seqname_FAMcounts[seqname].seq, "/", "", 1))
	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

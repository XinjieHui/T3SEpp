package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strings"
)

func main() {
	if len(os.Args) <= 1 {
		fmt.Printf("There is no input file!\n")
		return
	}
	inputFileName := os.Args[1]
	inputFile, openErr := os.Open(inputFileName)
	if openErr != nil {
		fmt.Printf("Error happened in opening %s\n", inputFileName)
		return
	}
	defer inputFile.Close()
	inputReader := bufio.NewReader(inputFile)
	var seq_name, seq string
	var seqlen int
	Llocation, Llocation16 := 0, 0
	aL, aL16 := 0, 0
	for {
		inputstring, readErr := inputReader.ReadString('\n')
		inputstring = seqTrim(inputstring)
		if readErr == io.EOF {
			break
		}
		pat, _ := regexp.MatchString("^>", inputstring) //也可以：pat := strings.Contains(inputstring, ">")
		seqlen = len(seq)
		if pat && seqlen >= 1 {
			seq = seqTrim(seq)
			for { //先循环所有G的位置，判断有无符合条件
				Llocation = strings.Index(seq[Llocation:], "G")
				if Llocation == -1 || aL+Llocation+28 > seqlen {
					break
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+26], "CCACG") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "AT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+25], "CCAC") && strings.ContainsAny(seq[aL+Llocation+25:aL+Llocation+26], "AT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACCTA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TAACTCA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TAACCAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TGACTAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TCACTTA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAG") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TCACCTG") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "CAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACTCA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}
				if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GATC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACTAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
				}

				Llocation = aL + Llocation + 1
				aL = Llocation //a用于累加每一次循环,L的位置
			}
			for { //先循环所有G的位置，判断有无符合条件
				Llocation16 = strings.Index(seq[Llocation16:], "G")
				if Llocation16 == -1 || aL16+Llocation16+29 > seqlen {
					break
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+27], "CCACG") && strings.ContainsAny(seq[aL16+Llocation16+27:aL16+Llocation16+28], "AT") && strings.Contains(seq[aL16+Llocation16+28:aL16+Llocation16+29], "A") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+26], "CCAC") && strings.ContainsAny(seq[aL16+Llocation16+26:aL16+Llocation16+27], "AT") && strings.Contains(seq[aL16+Llocation16+28:aL16+Llocation16+29], "A") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACCTA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TAACTCA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TAACCAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TGACTAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TCACTTA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAG") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TCACCTG") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "CAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACTCA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}
				if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GATC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACTAA") {
					fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
				}

				Llocation16 = aL16 + Llocation16 + 1
				aL16 = Llocation16 //a用于累加每一次循环,L的位置
			}

			seq = ""
			Llocation = 0
			aL = 0
			Llocation16 = 0
			aL16 = 0
		}
		if pat {
			seq_name = inputstring[1:]

		}
		if !pat {
			seq = seq + inputstring
		}
	}

	if len(seq) >= 1 { //此是输出最后一条序列
		seq = seqTrim(seq)
		for { //先循环所有G的位置，判断有无符合条件
			Llocation = strings.Index(seq[Llocation:], "G")
			if Llocation == -1 || aL+Llocation+28 > seqlen {
				break
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+26], "CCACG") && strings.ContainsAny(seq[aL+Llocation+26:aL+Llocation+27], "AT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+25], "CCAC") && strings.ContainsAny(seq[aL+Llocation+25:aL+Llocation+26], "AT") && strings.Contains(seq[aL+Llocation+27:aL+Llocation+28], "A") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACCTA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TAACTCA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TAACCAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TGACTAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TCACTTA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GAAG") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "TCACCTG") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "CAAC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACTCA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}
			if strings.Contains(seq[aL+Llocation+1:aL+Llocation+5], "GATC") && strings.Contains(seq[aL+Llocation+21:aL+Llocation+28], "CCACTAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL+Llocation+1, seq[aL+Llocation:aL+Llocation+28])
			}

			Llocation = aL + Llocation + 1
			aL = Llocation //a用于累加每一次循环,L的位置
		}
		for { //先循环所有G的位置，判断有无符合条件
			Llocation16 = strings.Index(seq[Llocation16:], "G")
			if Llocation16 == -1 || aL16+Llocation16+29 > seqlen {
				break
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+27], "CCACG") && strings.ContainsAny(seq[aL16+Llocation16+27:aL16+Llocation16+28], "AT") && strings.Contains(seq[aL16+Llocation16+28:aL16+Llocation16+29], "A") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+26], "CCAC") && strings.ContainsAny(seq[aL16+Llocation16+26:aL16+Llocation16+27], "AT") && strings.Contains(seq[aL16+Llocation16+28:aL16+Llocation16+29], "A") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACCTA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TAACTCA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TAACCAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TGACTAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TCACTTA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GAAG") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "TCACCTG") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "CAAC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACTCA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}
			if strings.Contains(seq[aL16+Llocation16+1:aL16+Llocation16+5], "GATC") && strings.Contains(seq[aL16+Llocation16+22:aL16+Llocation16+29], "CCACTAA") {
				fmt.Printf("%s\tHrpL\t%d\t%s\n", seq_name, aL16+Llocation16+1, seq[aL16+Llocation16:aL16+Llocation16+29])
			}

			Llocation16 = aL16 + Llocation16 + 1
			aL16 = Llocation16 //a用于累加每一次循环,L的位置
		}

		seq = ""
		Llocation = 0
		aL = 0
		Llocation16 = 0
		aL16 = 0
	}
}
func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}

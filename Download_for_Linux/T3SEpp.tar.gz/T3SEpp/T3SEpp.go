//
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"

	"strings"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("There is no inputfile!\n")
		return
	}
	matixfilename := os.Args[1]
	matixfile, openmatixErr := os.Open(matixfilename)
	if openmatixErr != nil {
		fmt.Printf("打开%s错误", matixfilename)
	}
	defer matixfile.Close()
	matixReader := bufio.NewReader(matixfile)
	var firstlines []string
	aminomaps := make(map[string]int)
	for {
		matixraw, readmatixErr := matixReader.ReadString('\n')
		matixraw = seqTrim(matixraw)

		if strings.Contains(matixraw, "flBlast") {
			matixraw = matixraw + "\tT3SEpp"
			fmt.Println(matixraw)
			firstlines = strings.Split(matixraw, "\t")
			for i, s := range firstlines {

				aminomaps[s] = i //类别对应的序号
			}
			continue
		}
		if len(matixraw) > 1 {
			var score float64 = 0.0
			lineblocks := strings.Split(matixraw, "\t")
			if lineblocks[aminomaps["sigHMM"]] == "1" {
				score += 0.35
			} else if lineblocks[aminomaps["sigHMM"]] == "0" && lineblocks[aminomaps["T3SEppML"]] == "1" {
				score += 0.30
			}
			if lineblocks[aminomaps["flBlast"]] == "1" || lineblocks[aminomaps["effectHMM"]] == "1" {
				score += 0.2
			}
			if lineblocks[aminomaps["cbdHMM"]] == "1" {
				score += 0.07
			}
			if lineblocks[aminomaps["transHMM"]] == "1" {
				score += 0.2
			}
			if lineblocks[aminomaps["TMHMM"]] == "1" {
				score += 0.02
			}
			if lineblocks[aminomaps["PSORTb"]] == "1" {
				score += 0.06
			}
			if lineblocks[aminomaps["SignalP"]] == "1" {
				score += 0.15
			}
			if score >= 1 {
				score = 1
				fmt.Printf("%s\t%f\n", matixraw, score)
			} else {
				fmt.Printf("%s\t%f\n", matixraw, score)
			}

		}
		if readmatixErr == io.EOF {
			break
		}
	}

}

func seqTrim(s string) string {
	s = strings.Trim(s, "\r\n")
	s = strings.Trim(s, "\n")
	return s
}
